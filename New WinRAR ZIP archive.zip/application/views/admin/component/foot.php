<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<script src="<?= base_url() ?>assets/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/js/dataTables.bootstrap4.js"></script>
<script src="<?= base_url() ?>assets/js/sb-admin-2.min.js"></script>
<script src="<?= base_url() ?>assets/js/admin.js"></script>
</html>

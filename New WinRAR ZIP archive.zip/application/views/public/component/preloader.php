<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<?php if($use_preloader) : ?>
<div class="preloader" >
	<lottie-player src="https://assets1.lottiefiles.com/packages/lf20_zakgeffb.json" mode="bounce"
				   background="transparent" speed="2" style="width: 300px; height: 300px;" loop
				   autoplay></lottie-player>
	<h4>
		Mohon tunggu, ya!
	</h4>
	<small>
		Lagi nyiapin rekomendasi buat kamu nih ...
	</small>
</div>
<?php endif; ?>
